﻿<?PHP
session_start();
if(isset($_SESSION['nome_usu_sessao']))
	{
		?>
        <div class="padding20"><?PHP echo 'Olá '.$_SESSION['nome_usu_sessao'].', Seja bem vindo!'; ?></div><?PHP
	}
?>
<link rel="stylesheet" href="../css/style.css">
<div class="menu">Menu</div>
<p><a href="../login_de_usuario/cadastro.php">Cadastro de usuários</a></p>
<p><a href="../login_de_usuario/login.php">Login</a></p>
<p><a href="../login_de_usuario/logout.php">Logout</a></p>